sudo docker build -t  docker.synapse.org/syn11051567/test2:test6 .
sudo docker run docker.synapse.org/syn11051567/test2:test6 ./score_sc2.sh
